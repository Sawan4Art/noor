# HashiCorp Inspired Design System

Design system details have been moved to: https://getdesign.md/hashicorp/design-md

You can also view previews, dark mode examples, and download options on getdesign.md.
